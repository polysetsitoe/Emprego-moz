// Configuração da API
const API_BASE_URL = 'https://5002-izuao1ym45ohgvf4slnvm-f57fc3d0.manusvm.computer';

// Dados simulados para demonstração
let jobs = [
    {
        id: 1,
        title: "Desenvolvedor Web Frontend",
        company: "TechMoz Solutions",
        city: "Maputo",
        category: "Tecnologia",
        type: "Tempo Integral",
        deadline: "2025-08-15",
        contactEmail: "rh@techmoz.co.mz",
        description: "Procuramos um desenvolvedor frontend experiente...",
        requirements: "React, JavaScript, CSS",
        status: "validated",
        publishedAt: new Date().toISOString()
    }
];

let currentUser = null;
let resetCodes = {};

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM carregado');
    initializeApp();
});

function initializeApp() {
    console.log('Inicializando aplicação');
    loadJobs();
    setupEventListeners();
    showSection('home');
}

function setupEventListeners() {
    console.log('Configurando event listeners');
    
    // Navegação
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('href').substring(1);
            showSection(section);
        });
    });

    // Botões de login/registo
    const loginBtn = document.querySelector('button[onclick="showLoginModal()"]');
    if (loginBtn) {
        loginBtn.onclick = showLoginModal;
    }

    const registerBtn = document.querySelector('button[onclick="showRegisterModal()"]');
    if (registerBtn) {
        registerBtn.onclick = showRegisterModal;
    }

    // Formulários
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    const createJobForm = document.getElementById('createJobForm');
    if (createJobForm) {
        createJobForm.addEventListener('submit', handleCreateJob);
    }

    const createCVForm = document.getElementById('createCVForm');
    if (createCVForm) {
        createCVForm.addEventListener('submit', handleCreateCV);
    }
}

function showSection(sectionName) {
    console.log('Mostrando secção:', sectionName);
    
    // Esconder todas as secções
    document.querySelectorAll('main > section').forEach(section => {
        section.style.display = 'none';
    });

    // Mostrar secção solicitada
    const targetSection = document.getElementById(sectionName);
    if (targetSection) {
        targetSection.style.display = 'block';
    }

    // Atualizar navegação ativa
    document.querySelectorAll('nav a').forEach(link => {
        link.classList.remove('active');
    });
    
    const activeLink = document.querySelector(`nav a[href="#${sectionName}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
}

function loadJobs() {
    console.log('Carregando vagas');
    const jobsContainer = document.getElementById('jobsContainer');
    if (!jobsContainer) return;

    // Filtrar apenas vagas validadas
    const validatedJobs = jobs.filter(job => job.status === 'validated');
    
    if (validatedJobs.length === 0) {
        jobsContainer.innerHTML = '<p>Nenhuma vaga disponível no momento.</p>';
        return;
    }

    jobsContainer.innerHTML = validatedJobs.map(job => `
        <div class="job-card">
            <h3>${job.title}</h3>
            <p><strong>Empresa:</strong> ${job.company}</p>
            <p><strong>Localização:</strong> ${job.city}</p>
            <p><strong>Categoria:</strong> ${job.category}</p>
            <p><strong>Tipo:</strong> ${job.type}</p>
            <p><strong>Prazo:</strong> ${new Date(job.deadline).toLocaleDateString('pt-PT')}</p>
            <p>${job.description}</p>
            <button onclick="viewJobDetails(${job.id})">Ver Detalhes</button>
        </div>
    `).join('');
}

function viewJobDetails(jobId) {
    const job = jobs.find(j => j.id === jobId);
    if (!job) return;

    alert(`
Título: ${job.title}
Empresa: ${job.company}
Localização: ${job.city}
Categoria: ${job.category}
Tipo: ${job.type}
Prazo: ${new Date(job.deadline).toLocaleDateString('pt-PT')}

Descrição:
${job.description}

Requisitos:
${job.requirements}

Contacto: ${job.contactEmail}
    `);
}

function showLoginModal() {
    console.log('Mostrando modal de login');
    const modal = document.getElementById('loginModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

function showRegisterModal() {
    console.log('Mostrando modal de registo');
    const modal = document.getElementById('registerModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeModal(modalId) {
    console.log('Fechando modal:', modalId);
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

async function handleLogin(event) {
    event.preventDefault();
    console.log('Processando login');

    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;

    // Validação de admin
    if (email === 'suporte.empregomoz@gmail.com' && password === 'admin123') {
        currentUser = {
            name: 'Administrador',
            email: email,
            isAdmin: true
        };
        
        showSuccessMessage('Login realizado com sucesso!');
        closeModal('loginModal');
        updateUserInterface();
        return;
    }

    // Simulação de outros utilizadores
    if (email && password) {
        currentUser = {
            name: 'Utilizador',
            email: email,
            isAdmin: false
        };
        
        showSuccessMessage('Login realizado com sucesso!');
        closeModal('loginModal');
        updateUserInterface();
    } else {
        showErrorMessage('Credenciais inválidas!');
    }
}

async function handleRegister(event) {
    event.preventDefault();
    console.log('Processando registo');

    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;

    if (!name || !email || !password) {
        showErrorMessage('Por favor, preencha todos os campos!');
        return;
    }

    // Simulação de registo
    showSuccessMessage('Conta criada com sucesso! Pode fazer login agora.');
    closeModal('registerModal');
}

async function handleCreateJob(event) {
    event.preventDefault();
    console.log('Criando nova vaga');

    const jobData = {
        title: document.getElementById('jobTitle').value,
        company: document.getElementById('jobCompany').value,
        city: document.getElementById('jobCity').value,
        category: document.getElementById('jobCategory').value,
        type: document.getElementById('jobType').value,
        deadline: document.getElementById('jobDeadline').value,
        contactEmail: document.getElementById('jobEmail').value,
        description: document.getElementById('jobDescription').value,
        requirements: document.getElementById('jobRequirements').value,
        suggestions: document.getElementById('jobSuggestions').value || ''
    };

    // Validação completa
    if (!jobData.title || !jobData.company || !jobData.city || !jobData.category || 
        !jobData.type || !jobData.deadline || !jobData.contactEmail || 
        !jobData.description || !jobData.requirements) {
        showErrorMessage('Por favor, preencha todos os campos obrigatórios!');
        return;
    }

    // Validar e-mail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(jobData.contactEmail)) {
        showErrorMessage('Por favor, insira um e-mail válido!');
        return;
    }

    // Validar data
    const deadlineDate = new Date(jobData.deadline);
    const today = new Date();
    if (deadlineDate <= today) {
        showErrorMessage('O prazo de candidatura deve ser uma data futura!');
        return;
    }

    try {
        const response = await fetch(`${API_BASE_URL}/api/publish-job`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(jobData)
        });

        const result = await response.json();

        if (result.success) {
            showSuccessMessage('Vaga publicada com sucesso! Aguarde a validação do administrador.');
            document.getElementById('createJobForm').reset();
        } else {
            showErrorMessage(result.message || 'Erro ao publicar vaga. Tente novamente.');
        }
    } catch (error) {
        console.error('Erro ao enviar vaga:', error);
        showErrorMessage('Erro ao enviar vaga. Verifique sua conexão e tente novamente.');
    }
}

async function handleCreateCV(event) {
    event.preventDefault();
    console.log('Criando CV');

    const cvData = {
        name: document.getElementById('cvName').value,
        email: document.getElementById('cvEmail').value,
        phone: document.getElementById('cvPhone').value,
        city: document.getElementById('cvCity').value,
        education: document.getElementById('cvEducation').value,
        experience: document.getElementById('cvExperience').value,
        skills: document.getElementById('cvSkills').value
    };

    // Validação
    if (!cvData.name || !cvData.email || !cvData.phone) {
        showErrorMessage('Por favor, preencha os campos obrigatórios!');
        return;
    }

    // Simulação de geração de PDF
    showSuccessMessage('CV criado com sucesso! O download começará em breve.');
    
    // Aqui seria a lógica real de geração de PDF
    setTimeout(() => {
        alert('Funcionalidade de PDF será implementada em breve!');
    }, 1000);
}

function updateUserInterface() {
    const loginBtn = document.querySelector('button[onclick="showLoginModal()"]');
    const registerBtn = document.querySelector('button[onclick="showRegisterModal()"]');
    
    if (currentUser) {
        if (loginBtn) loginBtn.style.display = 'none';
        if (registerBtn) registerBtn.style.display = 'none';
        
        // Adicionar botão de admin se for administrador
        if (currentUser.isAdmin) {
            const nav = document.querySelector('nav');
            if (nav && !document.getElementById('adminBtn')) {
                const adminBtn = document.createElement('button');
                adminBtn.id = 'adminBtn';
                adminBtn.textContent = 'Admin';
                adminBtn.onclick = showAdminPanel;
                nav.appendChild(adminBtn);
            }
        }
    }
}

function showAdminPanel() {
    console.log('Mostrando painel de admin');
    alert('Painel de administração será implementado em breve!');
}

function showSuccessMessage(message) {
    console.log('Sucesso:', message);
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success';
    alertDiv.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentElement) {
            alertDiv.remove();
        }
    }, 5000);
}

function showErrorMessage(message) {
    console.log('Erro:', message);
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-error';
    alertDiv.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentElement) {
            alertDiv.remove();
        }
    }, 5000);
}

// Funções globais para compatibilidade
window.showSection = showSection;
window.showLoginModal = showLoginModal;
window.showRegisterModal = showRegisterModal;
window.closeModal = closeModal;
window.viewJobDetails = viewJobDetails;
window.showAdminPanel = showAdminPanel;

